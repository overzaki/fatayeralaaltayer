"use client";
import React from "react";
import SearchBar from "../../components/Search/SearchBar";

const search = () => {
  return (
    <div>
      <SearchBar />
    </div>
  );
};

export default search;
