import React from "react";

const Footer = () => {
  return (
    <div className="p-7 flex items-center justify-center">
      <span className="font-extralight">Powered By U</span>
    </div>
  );
};

export default Footer;
