import React from "react";
// import "./ToggleSwitch.css";
const ToggleSwitch = () => {
  return <input className="toggle" type="checkbox" />;
};

export default ToggleSwitch;
